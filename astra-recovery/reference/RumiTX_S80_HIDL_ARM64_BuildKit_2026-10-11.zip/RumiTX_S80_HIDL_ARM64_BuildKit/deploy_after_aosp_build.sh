#!/usr/bin/env bash
set -euo pipefail
BIN="${1:-rumitx-build-out/rumitx_hidl_client}"
[[ -f "$BIN" ]] || { echo "Missing built binary: $BIN" >&2; exit 2; }
file "$BIN"
readelf -h "$BIN" | grep -E 'Class:|Machine:|Type:'
readelf -d "$BIN" | grep NEEDED || true
adb push "$BIN" /data/local/tmp/rumitx_hidl_client
adb shell chmod 0755 /data/local/tmp/rumitx_hidl_client
# Safe: does not call init, app_start, or speak_enable.
adb shell '/data/local/tmp/rumitx_hidl_client --probe'
echo 'Only after reviewing probe output and closing stock UI, manually run:'
echo "adb shell '/data/local/tmp/rumitx_hidl_client --rx --timeout 30'"
