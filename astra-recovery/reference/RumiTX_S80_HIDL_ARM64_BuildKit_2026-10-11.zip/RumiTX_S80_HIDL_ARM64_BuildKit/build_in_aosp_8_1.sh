#!/usr/bin/env bash
# Place this script at the root of an Android 8.1 source checkout, with
# bundled vendor/ subtree merged into its vendor/ directory.
set -euo pipefail
if [[ ! -f build/envsetup.sh ]]; then
  echo 'Run from a complete AOSP 8.1 source root (build/envsetup.sh missing).' >&2
  exit 2
fi
if [[ ! -f vendor/hct/rumitx/main.cpp ]]; then
  echo 'Copy this package vendor/ directory into the AOSP tree.' >&2
  exit 2
fi
source build/envsetup.sh
if [[ -z "${TARGET_PRODUCT:-}" ]]; then
  echo 'Select an ARM64 product first, e.g. lunch aosp_arm64-userdebug' >&2
  exit 2
fi
if [[ "$(get_build_var TARGET_ARCH)" != arm64 ]]; then
  echo 'TARGET_ARCH must be arm64 (64-bit S80 runtime).' >&2
  exit 2
fi
# The source package contains Oreo-style Soong genrules invoking the tree's hidl-gen.
m rumitx_hidl_client
PRODUCT_OUT="$(get_build_var PRODUCT_OUT)"
BIN="$PRODUCT_OUT/system/bin/rumitx_hidl_client"
if [[ ! -f "$BIN" ]]; then
  echo "Built binary was not found at $BIN; use find \"$PRODUCT_OUT\" -name rumitx_hidl_client." >&2
  exit 3
fi
mkdir -p ./rumitx-build-out
cp -v "$BIN" ./rumitx-build-out/rumitx_hidl_client
file ./rumitx-build-out/rumitx_hidl_client || true
readelf -d ./rumitx-build-out/rumitx_hidl_client | grep NEEDED || true
sha256sum ./rumitx-build-out/rumitx_hidl_client
