#!/usr/bin/env bash
set -euo pipefail
adb devices
adb shell 'echo ====ANDROID; getprop ro.build.version.release; getprop ro.build.version.sdk; getprop ro.product.cpu.abi; getprop ro.product.cpu.abilist; echo ====SHELL; id; id -Z; getenforce; echo ====HIDL; lshal | grep -i talkie || true; echo ====RUNTIME; for x in libhidlbase.so libhidltransport.so libhwbinder.so libutils.so libcutils.so liblog.so libbase.so libbinder.so libhardware.so libstdc++.so libc++.so android.hidl.base@1.0.so; do if [ -f "/system/lib64/$x" ]; then ls -l "/system/lib64/$x"; elif [ -f "/vendor/lib64/$x" ]; then ls -l "/vendor/lib64/$x"; else echo "MISSING: $x"; fi; done'
