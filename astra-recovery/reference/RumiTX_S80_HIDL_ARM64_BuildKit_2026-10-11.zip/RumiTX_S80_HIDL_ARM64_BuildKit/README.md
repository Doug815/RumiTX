# RumiTX 2030 — S80 HIDL ARM64 C++ build kit (Oreo 8.1)

**Status: source package, NOT a compiled or device-tested ARM64 binary.**

The requested executable cannot be honestly delivered by this host: it has **no Android 8.1/AOSP platform source tree, no `hidl-gen`, no Android platform sysroot/runtime linkage libraries, and no Android NDK installed**. A generic host Clang or standalone NDK is not sufficient to link Oreo's private HIDL C++ APIs. Nothing in this package is represented as a tested ELF binary. The sources are ready to transplant into a compatible Android 8.1 platform build tree, subject to platform-dependent Soong/HIDL generator adjustments.

## What the program does

- `--probe` (default is **not** probe; explicit flag required): calls `configureRpcThreadpool(2, false)`, then `ITalkiePort::tryGetService("default")` and prints whether a remote service was obtained. This mode does not invoke any hardware-changing HAL method. Exit 0 = service object acquired; not proof of permission to call all methods or actual RX success.
- `--rx --timeout 30`: calls `talkie_init()`, `talkie_app_start()`, registers a local `ITalkiePortCallback`, then queues `talkie_speak_enable(callback)` as a HIDL `oneway` method. It waits up to 30 seconds for the first `reportResults(int32)` callback and logs the raw callback value without assuming its success semantics; on callback or timeout, invokes `talkie_speak_disable()`, `talkie_app_exit()`, `talkie_deinit()` (as far as reached).
- No TX calls; does not call `/dev/ttyMT1`, direct ioctls, or GPIO APIs.
- Callback handling uses the Android HwBinder RPC threadpool so the main thread can wait safely.
- A *hard process watchdog* caps the RX invocation lifetime if synchronous cleanup hangs, but **does not cancel a blocked driver ioctl inside the vendor HAL process**. Consequently the HAL might remain in an abnormal state and require app restart/device reboot. This is a hardware-experiment caveat, not a solution to in-kernel stalls.

## Correct build environment

Use a **complete Android Open Source Project 8.1.0** checkout (prefer a near-device build branch, API 27), including Soong, build tools, HIDL generator and platform HIDL headers/libraries. This is a *platform* source build. Generic `ndk-build` or NDK CMake cannot compile it as written: libhwbinder, libhidltransport and the generated HIDL interface code are not ordinary stable NDK APIs. Older S80 MediaTek vendor binaries may have compatibility quirks, so do not copy modern Android HIDL libraries onto the phone.

Copy the `vendor/hct/...` subtree in this zip into the AOSP checkout, preserving the path structure. From the AOSP checkout:

```bash
source build/envsetup.sh
lunch aosp_arm64-userdebug       # Or another 64-bit target matching Android 8.1
m rumitx_hidl_client             # Oreo Soong runs the hidl-gen genrules
file out/target/product/aosp_arm64/system/bin/rumitx_hidl_client
readelf -d out/target/product/aosp_arm64/system/bin/rumitx_hidl_client | grep NEEDED
```

Optional wrapper: copy `build_in_aosp_8_1.sh` to the AOSP root after `lunch` and execute it there. It copies the built binary to `rumitx-build-out/` and prints its ELF dependencies. `lunch` names and output paths depend on your AOSP checkout; wrapper uses `get_build_var PRODUCT_OUT` to reduce guesswork.

**Important potential build adaptation:** Reconstructed interfaces are not original source files. If the Oreo generator errors on a local interface name or a generated filename, run `hidl-gen -L c++-sources ...` and `hidl-gen -L c++-headers ...` manually within AOSP to inspect the actual filenames, then align the `out` lists in `vendor/hct/hardware/talkie/1.0/Android.bp`. Do not invent/overwrite the stock package globally. `-rvendor.hct.hardware:vendor/hct/hardware` must match the .hal directory hierarchy. Both callbacks and service proxies need to be linked; `whole_static_libs` prevents removing static registration code for generated binder constructors.

## Deploy and verify safely

1. On computer with `adb`, run `check_device_runtime.sh` and save the output. It performs only reads.
2. Check `readelf -d ... | grep NEEDED` against `/system/lib64` or `/vendor/lib64` on the actual S80.
3. `deploy_after_aosp_build.sh /path/to/rumitx_hidl_client` pushes the executable, sets mode 0755, and runs **only `--probe`**; it does not start RX.
4. Only after a passing probe and with the stock Talkie app closed, explicitly run:

```bash
adb shell '/data/local/tmp/rumitx_hidl_client --rx --timeout 30'
adb shell 'logcat -d -b all -v threadtime | grep -Ei "RUMITX|hct|intercom|avc: denied|talkie"'
adb shell 'dmesg | grep -Ei "hct|speak|intercom|aw pa|gpio"'
```

Run the RX test on a legal, permitted test frequency or shielded bench setup, and avoid unsanctioned monitoring of protected communications. Keep the existing RumiTX TX daemon and stock app from competing for lifecycle ownership; if needed, disable the TX daemon during first RX lifecycle testing. There is no RF transmission logic in this HIDL client.

## Exact dependencies / linkage policy

The **generated vendor interface glue is linked statically into the executable** so the S80 needs no `/vendor/lib64/vendor.hct.hardware.talkie@1.0.so` client library. The following Android 8.1 shared dependencies remain at runtime (depending on the final linker's ELF NEEDED list):

- `libhidlbase.so`
- `libhidltransport.so`
- `libhwbinder.so`
- `libutils.so`
- `libcutils.so`
- `liblog.so`
- `android.hidl.base@1.0.so`
- C++ runtime + Android Bionic, likely `libc++.so`, `libc.so`, `libm.so`, `libdl.so`

Do not assume every item is a direct ELF NEEDED dependency; only **`readelf -d` on the actual compiled ELF** proves that. Validate each NEEDED soname and its dependency closure on the phone, and resolve any linker namespace restrictions before RX testing.

## What is recovered versus not recovered

Known from original stock VDEX proxy: method names, order/transaction IDs 1..9, scalar arguments, oneway `talkie_speak_enable(callback)`, `ITalkiePortCallback::reportResults(int32)`. Vendor returned integer meanings and callback oneway-vs-synchronous characteristics must be confirmed. `.hal` files and hash chains are reconstructed, not originals. Reconstructed generated interface can still work if transaction IDs and data layout match; it is **not** guaranteed that `getService` works with mismatched generated interface hashes, vendor transport declarations, or nonstandard implementation behavior. Rebuilding an interface library does not patch or install anything in the stock HAL service.

## Exit status

- 0: safe probe connected; or RX callback arrived and cleanup calls returned at transport level (neither establishes audible voice)
- 2: usage
- 3: service not acquired
- 4: non-binderized service in `--rx`
- 5: `talkie_init` transport error
- 6: `talkie_app_start` transport error
- 7: `talkie_speak_enable` submission transport error
- 8: RX callback did not arrive before timeout
- 124: process-hard-timeout fallback (vendor state unknown)

**Next verification step:** Once built, `--probe` establishes a true binder-client reachability test from `u:r:shell:s0`; if it fails, collect `logcat` for `avc: denied` and the exact linker error. If it succeeds, do the isolated `--rx` test and compare dmesg interrupt/amp order against stock startup.
